;(function($){$.extend($.fn,{swip_config:{},startX:0,startY:0,transX:0,transY:0,lastX:0,lastY:0,currentX:0,currentY:0,addHandler:function(obj,type,fn){if(obj&&obj.attachEvent){obj.attachEvent("on"+type,fn)}else{if(obj.addEventListener){obj.addEventListener(type,fn,false)}else{obj["on"+type]=fn}}},bind_fn:function(obj,fn){return function(){fn.apply(obj,arguments)}},swip:function(config){$(this).addClass("swip");this.swip_config=config;this.addHandler($(this)[0],"touchstart",this.bind_fn(this,this.touch_start));this.addHandler($(this)[0],"touchmove",this.bind_fn(this,this.touch_move));this.addHandler($(this)[0],"touchend",this.bind_fn(this,this.touch_end));return $(this)},touch_click:function(callback){var that=this;this.swip({start:function(){callback.apply(that,arguments)}})},touch_start:function(e){if(!event.touches.length){return}var touch=event.touches[0];this.startX=touch.pageX;this.startY=touch.pageY;this.transX=0;this.transY=0;if(this.swip_config.start!=null){this.swip_config.start(this.startX,this.startY)}event.preventDefault()},touch_move:function(e){if(!event.touches.length){return}var touch=event.touches[0];this.currentX=touch.pageX;this.currentY=touch.pageY;this.transX=this.startX-touch.pageX;this.transY=this.startY-touch.pageY;this.lastX=this.currentX;this.lastY=this.currentY;e.preventDefault()},touch_end:function(){if(!$(this).hasClass("swip")){return}if(this.swip_config.speed!=null){this.swip_config.speed(this.transX,this.transY,this)}}})})(Zepto);
var Action=function(){this.changed=false;this.played=false};Action.prototype={"hideAlert":function(){$(".alert").removeClass("show")},"submit":function(){wa.sendEvent("click","submit");var name=$("#val_name").val(),sex=$('input[name="sex"]:checked').val(),tel=$("#val_tel").val(),province=$("#province").val(),city=$("#city").val();if(!name||!tel||province=="none"){$("#info").html("内容填写不完整！");$(".alert").addClass("show");return}var form=new WxMoment.Form({appid:"wxe49dece6622a2af6",qid:"84",name:name,sex:sex,tel:tel,prov:province,city:city});form.submit(function(){$("#info").html("您的信息提交成功！");$(".alert").addClass("show");wa.sendEvent("click","submit_success")},function(){$("#info").html("您的信息提交失败！");$(".alert").addClass("show");wa.sendEvent("click","submit_failure")});return},"change":function(){if(this.changed){return}this.changed=true;wa.sendEvent("click","price");$(".show").addClass("change");$(".hide").addClass("change")},"play":function(){this.played=true;playAudio(2);video.getPlayer().play()},"link":function(){wa.sendEvent("jump","link");setTimeout(function(){window.location.href="http://x25.senova.com.cn/m/index.html"},200)}};

var page_config={pages:[{id:"page_1",animates:[],dom:[{type:"img",src:"page_1_bg_a.jpg",rect:{w:320,h:550,x:0,y:0},s:1,comment:"bg",time:1000,wait:100},{type:"img",src:"page_2_3_a.jpg",class:"appear-fast t0",rect:{w:320,h:550,x:0,y:0},s:1,comment:"bg",time:1000,wait:100},{type:"img",src:"page_2_2_a.png",class:"top t0",rect:{w:320,h:215,x:0,y:0},s:1,comment:"上",time:1000,wait:100},{type:"img",src:"page_2_4_a.png",class:"bottom t1",rect:{w:320,h:276,x:0,y:274},s:1,comment:"内饰",time:1000,wait:100},{type:"img",class:"appear-middle t4",src:"page_1_3.png",rect:{w:93,h:52,x:185,y:289},s:1,comment:"导航屏幕",time:1000,wait:100},{type:"img",class:"bottom t2",src:"page_7_2.png",rect:{w:288,h:185,x:0,y:365},s:1,comment:"手",time:1000,wait:100},{type:"img",class:"appear-middle t3",src:"page_7_3.png",rect:{w:99,h:58,x:151,y:384.5},s:2,comment:"鸟",time:1000,wait:100},{type:"div",class:"right middle t4",src:"page_7_4.png",rect:{w:315,h:141,x:0,y:120},s:1,comment:"首页--标题",time:1000,wait:100}]},{id:"page_2",animates:[],dom:[{type:"img",src:"page_2_bg.jpg",rect:{w:320,h:550,x:0,y:0},s:1,comment:"bg",time:1000,wait:100},{type:"img",src:"page_2_2.png",class:"top w1 d2",rect:{w:320,h:220,x:0,y:0},s:1,comment:"弯路",time:1000,wait:100},{type:"img",src:"page_2_3.png",class:"bottom w2 d2",rect:{w:320,h:426,x:0,y:125},s:1,comment:"路",time:1000,wait:100},{type:"img",src:"page_1_z.png",class:"car w3",rect:{w:410,h:194,x:-119,y:288},s:1,comment:"车",time:1000,wait:100},{type:"spirit",class:"light2 w4",src:"light2.png",rect:{w:569/2,h:318/2,x:21,y:285},s:1,comment:"车",time:1000,wait:100},{type:"div",class:"left w4",src:"page_7_6.png",rect:{w:315,h:141,x:0,y:127},s:2,comment:"山路-标题",time:1000,wait:100}]},{id:"page_3",animates:[{type:"spirit",w:109,n:5,time:300,wait:100,mode:"repeat"},{type:"spirit",w:129.5,n:5,time:399,wait:100,mode:"repeat"}],dom:[{type:"img",src:"page_3_bg_a.jpg",rect:{w:320,h:550,x:0,y:0},s:1,comment:"bg",time:1000,wait:100},{type:"img",class:"top w1",src:"page_1_2_a.png",rect:{w:320,h:200,x:0,y:0},s:1,comment:"花田",time:1000,wait:100},{type:"img",class:"bottom w2",src:"page_1_3_a.png",rect:{w:320,h:454,x:0,y:97},s:1,comment:"车",time:1000,wait:100},{type:"div",class:"right middle w3",src:"page_7_7.png",rect:{w:315,h:141,x:0,y:119},s:1,comment:"花田-标题",time:1000,wait:100},{type:"spirit",animates:[0],class:"appear-middle w3",src:"page_1_2_c.png",rect:{w:109,h:53,x:53,y:299},s:1,comment:"s",time:1000,wait:100},{type:"spirit",animates:[1],class:"appear-middle w3",src:"page_1_3_c.png",rect:{w:130,h:56,x:176,y:311},s:1,comment:"s",time:1000,wait:100},{type:"spirit",class:"light3 w3",src:"page_1_4_c.png",rect:{w:89,h:55,x:122,y:276},s:1,comment:"s",time:1000,wait:100}]},{id:"page_4",animates:[],dom:[{type:"img",src:"loading_bg.jpg",rect:{w:320,h:550,x:0,y:0},s:1,comment:"bg",time:1000,wait:100},{type:"div",src:"video-thumb.jpg",id:"WxMomentVideo",rect:{w:300,h:173,x:10,y:158},s:1,comment:"视频",time:1000,wait:100,real_click:"play"},{type:"img",src:"page_7_8.png",rect:{w:242,h:360,x:44,y:48},s:1,comment:"主题",time:1000,wait:100}]},{id:"page_5",animates:[{type:"spirit",w:30,n:3,time:200,wait:100,mode:"repeat"}],dom:[{type:"img",src:"page_5_2.jpg",rect:{w:320,h:550,x:0,y:0},s:1,comment:"内饰",time:1000,wait:100},{type:"img",class:"hide",src:"page_7_9.png",rect:{w:180,h:109,x:69,y:174},s:1,comment:"价格",time:1000,wait:100,real_click:"change"},{type:"img",class:"show",src:"page_1_a.png",rect:{w:86,h:23,x:117,y:223},s:2,comment:"手",time:1000,wait:100,real_click:"change"},{type:"spirit",class:"show",animates:[0],src:"page_1_b.png",rect:{w:30,h:30,x:104,y:214},s:2,comment:"sp",time:1000,wait:100,real_click:"change"}]},{id:"page_6",animates:[],dom:[{type:"img",src:"page_6_7.jpg",rect:{w:320,h:550,x:0,y:0},s:2,comment:"车",time:1000,wait:100},{type:"div",class:"form",id:"input_name",rect:{w:282,h:27,x:21,y:127},s:1,comment:"input1",time:1000,wait:100},{type:"div",class:"form",id:"input_sex",rect:{w:282,h:28,x:21,y:156},s:1,comment:"input2",time:1000,wait:100},{type:"div",class:"form",id:"input_mobile",rect:{w:282,h:28,x:21,y:186},s:1,comment:"input3",time:1000,wait:100},{type:"div",class:"form",id:"input_province",rect:{w:282,h:28,x:21,y:216},s:1,comment:"input4",time:1000,wait:100},{type:"div",class:"form",id:"input_city",rect:{w:282,h:27,x:21,y:246},s:1,comment:"input5",time:1000,wait:100},{type:"img",src:"page_6_8.png",rect:{w:112,h:39,x:43,y:285},s:2,comment:"btn_预约",time:1000,wait:100,real_click:"submit"},{type:"img",src:"page_6_9.png",rect:{w:112,h:39,x:169,y:285},s:2,comment:"btn_配置",time:1000,wait:100,real_click:"link"},{type:"div",src:"msg_mask.png",class:"alert",rect:{w:500,h:550,x:-90,y:0},s:998,comment:"mask",time:0,wait:0},{type:"div",src:"msg_bg.png",class:"alert",rect:{w:235,h:118,x:42.5,y:163},s:998,comment:"bg",time:0,wait:0},{type:"div",id:"info",class:"alert",rect:{w:200,h:30,x:60,y:178},s:998,comment:"text",time:0,wait:0},{type:"div",src:"msg_btn.png",class:"alert",rect:{w:112,h:38.5,x:104,y:224},s:998,comment:"btn",time:0,wait:0,real_click:"hideAlert"}]}]};

var Animate = function(){
    this.pages = page_config.pages;
    this.page_index = -1;
    this.stage_index = 0;
    this.startX = 0;
    this.touchPos = {x:0,y:0};
    this.renderGroup = [];
    this.startTime = -1;
    this.stopped = false;
};
Animate.prototype = {
    start:function(){
        playAudio(1);
        $("#music_btn").touch_click(function(){
            playAudio(1);
        });
        this.startTime = new Date().getTime();
        this.render();
    },
    render:function(){
        var timeNow = new Date().getTime();
        var dt = timeNow - a.startTime;
        for(var i = 0 ; i < a.renderGroup.length ; i ++){
            var _render = a.renderGroup[i];
            _render.update(dt);
            _render.render();
        };
        requestAnimationFrame(a.render);
    },
    addRenderer:function(dom,animates){
        var sr = new SpiritRenderer($(dom).find("div")[0]);
        for(var i = 0 ; i < animates.length ; i ++){
            sr.add(animates[i]);
        };
        if(sr.count() > 0){
            this.renderGroup.push(sr);
        }
    }
};
var SpiritRenderer = function(dom){
    this.spiritSteps = [];
    this.dom = dom;
    this.bg_pos = {left:0,top:0};
    this.frame_index = 0;
    this.canRender = true;
};
SpiritRenderer.prototype = {
    update:function(time){
        var dt = time - this.spiritSteps[0].wait;
        var at = dt % (this.spiritSteps[0].time * this.spiritSteps[0].n);
        this.frame_index = parseInt(at / this.spiritSteps[0].time);

        if(this.spiritSteps[0].mode == "once"){
            this.frame_index = parseInt(dt / this.spiritSteps[0].time);
            if(this.frame_index >=  this.spiritSteps[0].n){
                this.frame_index = this.spiritSteps[0].n - 1;
            };
            this.bg_pos = {
                left:this.frame_index * this.spiritSteps[0].w * -1,
                top:0
            };
        }else{
            this.frame_index = parseInt(at / this.spiritSteps[0].time);
            this.bg_pos = {
                left:this.frame_index * this.spiritSteps[0].w * -1,
                top:0
            };
        }
    },
    render:function(){
        if(!this.canRender){
            return;
        };
        $(this.dom).css({
            "background-position":this.bg_pos.left + "px " + this.bg_pos.top + "px"
        });
    },
    add:function(spiritConfig){
        this.spiritSteps.push(spiritConfig);
    },
    count:function(){
        return this.spiritSteps.length;
    }
};
var Render = function(){}
Render.prototype = {
    renderPage:function(page){
        var container = $("<div></div>").addClass("container").attr("id",page.id);
        for(var i = 0 ; i < page.dom.length ; i ++){
            var item = page.dom[i];
            var type = item.type;
            var dom;
            switch(type){
                case "img":
                    dom = $("<img>").attr("src","img/" + item.src);
                    $(dom).attr("width",item.rect.w);
                    $(dom).attr("height",item.rect.h);
                    break;
                case "div":
                    dom = $("<div></div>");
                    if(item.src){
                        $(dom).css("background","url(img/" + item.src +") left no-repeat")
                            .css("background-size","auto 100%");
                    }
                    if(item.html)$(dom).html(item.html);
                    $(dom).css("width",item.rect.w + "px");
                    $(dom).css("height",item.rect.h + "px");

                    break;
                case "spirit":
                    dom = $("<div></div>").addClass("spirit-container").width(item.rect.w).height(item.rect.h);
                    var spirit_dom = $("<div></div>").addClass("spirit").width(item.rect.w).height(item.rect.h)
                        .css({
                            "background" :"url(img/" + item.src + ") no-repeat"
                        });
                    $(spirit_dom).appendTo(dom);
                    break;
                default :break;
            };
            $(dom).css({
                "left":item.rect.x,
                "top":item.rect.y
            });
            if(item.real_click){
                var click = item.real_click;
                var args = item.args || false;
                $(dom).swip({
                    speed:function(_click,_args,_dom){
                        return function(x,y){
                            if(Math.abs(x) < 5){
                                if(_args != false){
                                    act[_click](_args,_dom);
                                }else{
                                    act[_click](_dom);
                                }
                                return false;
                            }
                            return false;
                        }
                    }(click,args,dom)
                });
            };
            if(item.class)$(dom).addClass(item.class);
            if(item.id)$(dom).attr("id",item.id);
            if(item.animates){
                var _animates = page.animates;
                var _sr = [];
                for(var j = 0 ; j < item.animates.length ; j ++ ){
                    _sr.push(_animates[item.animates[j]]);
                }
                a.addRenderer(dom,_sr);
            };
            $(dom).appendTo(container);
        }
        var page_dom = $("<section></section>").addClass("screen").attr("id",page.id + "_bg");
        $(container).appendTo(page_dom);
        $(page_dom).appendTo($("#wrap"));
    },
    render:function(){
        var pages = page_config.pages;
        for(var i = 0 ; i < pages.length ; i ++){
            this.renderPage(pages[i]);
        };
        $("<header></header>").attr("id","music").addClass("music-on").html("<audio src=\"media/1.mp3\" loop=\"loop\"  autoplay></audio>"+"<span  id=\"music_btn\"></span>").appendTo("body");
    }
};
function playAudio(type) {
    var audio = document.querySelectorAll('audio')[0] || {paused: true};
    if(type == 2){
        $("#music").removeClass("music-on");
        audio.pause();
        return;
    }else if(type == 3){
        $("#music").addClass("music-on");
        audio.play();
        return;
    };
    if (first_play && audio.paused) {
        first_play = false;
        $("#music").addClass("music-on");
        audio.play();
    } else if (first_play && !audio.paused) {
        first_play = false;
        $("#music").addClass("music-on");
    } else {
        if (audio.paused) {
            audio.play();
            $("#music").addClass("music-on");
        } else {
            audio.pause();
            $("#music").removeClass("music-on");
        }
    }
};
function resize(){
    var _scale = $("#wrap").width() * 1.0 / 320;
    var _transX = 0;
    var _page_scale = $("#wrap").width() / $("#wrap").height();
    var dx = 0;
    if(_page_scale > 640 / 930){
        _scale = _scale * ( 640 / 930 / _page_scale);
        var realWidth = 320 * _scale;
        dx = ($("#wrap").width() - realWidth ) / 2;
    }
    $(".container").css("-webkit-transform","translate(" + dx + "px) scale(" + _scale + ")");
    $("#music").css("-webkit-transform","translate(" + dx + "px) scale(" + _scale + ")");
};
function initForm(){
    $("#input_name").html("<span>姓名:</span><input id='val_name' />");
    $("#input_sex").html("<span>称呼:</span><input type=\"radio\" name=\"sex\" value=\"male\" checked/>先生&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"radio\" name=\"sex\" value=\"female\" />女士");
    $("#input_mobile").html("<span>电话:</span><input id='val_tel' type='tel' />");
    $("#input_province").html("<span>省份:</span><select id='province'></select>");
    $("#input_city").html("<span>城市:</span><select id='city'></select>");
    $("<option value='none'>请选择省份</option>").appendTo($("#province"));
    for(var i = 0 ; i < data.length ; i += 2){
        if(provinceName != data[i]){
            var newProvince = {
                provinceName:data[i],
                citys:[]
            };
            provinceArray.push(newProvince);
            newProvince.citys.push(data[i+1]);
            provinceName = data[i];
            $("<option value='" + provinceName + "'>" + provinceName + "</option>").appendTo($("#province"));
        }else{
            var province = provinceArray[provinceArray.length - 1];
            if(data[i+1] != data[i - 1]){
                province.citys.push(data[i+1]);
            }
        }
    }
    $("#province").on("change",function(){
        initCity($("#province").val());
    })
};
function initCity(provinceName){
    $("#city").html("");
    if(provinceName == "请选择省份"){
        return;
    }

    var province = null;
    for(var i = 0 ; i < provinceArray.length ; i ++){
        if(provinceName == provinceArray[i].provinceName){
            province = provinceArray[i];
        }
    }
    for(var i = 0 ; i < province.citys.length ; i ++){
        var cityName = province.citys[i];
        $("<option value='" + cityName + "'>" + cityName + "</option>").appendTo($("#city"));
    }
};
var provinceName = "-1";
var provinceArray = [];
var act;
var a;
var render = new Render();
var first_play = true;
var video;
var fileList = [];
var loader = new WxMoment.Loader();
for(var i = 0 ; i < page_config.pages.length ; i ++){
    var page = page_config.pages[i];
    var dom = page.dom;
    for(var j = 0; j < dom.length ; j ++){
        if(dom[j].src){
            fileList.push(dom[j].src);
        }
    }
}
fileList.push("page_1_bg_a.jpg");
fileList.push("page_2_bg.jpg");
fileList.push("page_3_bg_a.jpg");
loader.addProgressListener(function (e) {
    var percent = Math.round((e.completedCount / e.totalCount) * 100);
    document.getElementById("car_img").setAttribute("style","-webkit-transform:translateX(-" + (100-percent) + "%)");
});
loader.addCompletionListener(function () {
    act = new Action();
    a = new Animate();
    render.render();
    resize();
    pageSlider = new WxMoment.PageSlider({
        pages: $('.screen'),
        onSwipeUp: function(){
            if(this.index === 2){$("#arrow").addClass("gray")}
            if(this.index === 3){
                if(act.played){
                    video.getPlayer().pause();
                }
                $("#arrow").removeClass("gray");
            }
            if(this.index === 4){$("#arrow").addClass("hide");}
        },
        onSwipeDown: function () {
            if(this.index === 5){$("#arrow").removeClass("hide");}
            if(this.index === 4){$("#arrow").addClass("gray")}
            if(this.index === 3){
                if(act.played){
                    video.getPlayer().pause();
                }
                $("#arrow").removeClass("gray")
            }
        },
        onchange:function(){wa.sendEvent('swipe', 'page_' + (this.index+1));}
    });
    initForm();
    video = new WxMoment.Video({
        vid: vid,
        pic: pic,
        oninited: function () {
            //播放器在视频载入完毕触发
            $("#loader").css("display","none");
            wa.sendEvent('swipe', 'page_1');
            a.start();
        },
    });

});
var data=['黑龙江','齐齐哈尔','黑龙江','绥化','黑龙江','大庆','黑龙江','哈尔滨','黑龙江','佳木斯','青海','西宁','陕西','西安','陕西','渭南','陕西','汉中','陕西','榆林','陕西','延安','陕西','宝鸡','陕西','咸阳','重庆','重庆','重庆','重庆','重庆','重庆','重庆','万州','通辽','铁岭','辽宁','鞍山','辽宁','阜新','辽宁','锦州','辽宁','葫芦岛','辽宁','营口','辽宁','盘锦','辽宁','沈阳','辽宁','朝阳','辽宁','大连','贵州省','兴义','贵州','铜仁','贵州','贵阳','贵州','贵州','西藏','拉萨','福建','福清','福建','泉州','甘肃','白银','甘肃','天水','甘肃','兰州','湖南','长沙','湖南','郴州','湖南','衡阳','湖南','娄底','湖南','株洲','湖南','怀化','湖南','岳阳','湖北','黄石','湖北','襄阳','湖北','荆州','湖北','武汉','湖北','宜昌','湖北','十堰','海南','海口','浙江','金华','浙江','衢州','浙江','绍兴','浙江','温州','浙江','宁波','浙江','嘉兴','浙江','台州','河南','许昌','河南','济源','河南','鹤壁','河南','驻马店','河南','郑州','河南','焦作','河南','濮阳','河南','漯河','河南','洛阳','河南','洛阳','河南','新乡','河南','开封','河南','平顶山','河南','安阳','河南','安阳','河南','周口','河南','南阳','河南','信阳','河南','三门峡','河北','邯郸','河北','邢台','河北','衡水','河北','石家庄','河北','石家庄','河北','沧州','河北','沧州','河北','张家口','河北','廊坊','河北','定州','河北','唐山','河北','南宫','河北','保定易县','河北','保定','河北','保定','江西','赣州','江西','景德镇','江西','吉安','江西','南昌','江西','南昌','江西','九江','江西','上饶','江苏','镇江','江苏','连云港','江苏','苏州','江苏','盐城','江苏','淮安','江苏','泰州','江苏','无锡','江苏','常熟','江苏','常州','江苏','宿迁','江苏','如皋','江苏','南通市','江苏','南京','江苏','南京','新疆','阿克苏','新疆','石河子','新疆','库尔勒','新疆','伊宁','新疆','乌鲁木齐','新疆','乌鲁木齐','广西','桂林','广西','柳州','广西','南宁','广东','深圳','广东','河源','广东','江门','广东','惠州','广东','广州','广东','佛山','广东','中山','广东','东莞','广东','东莞','山西','阳泉','山西','长治','山西','运城','山西','朔州','山西','晋城','山西','忻州','山西','太原','山西','太原','山西','太原','山西','大同','山西','临汾','山东','青岛','山东','青岛','山东','诸城','山东','菏泽','山东','聊城','山东','烟台','山东','烟台','山东','潍坊','山东','滨州','山东','淄博','山东','济宁','山东','济南','山东','泰安','山东','枣庄','山东','日照','山东','日照','山东','德州','山东','威海','山东','临沂','山东','临沂','山东','东营','安徽','马鞍山','安徽','阜阳','安徽','蚌埠','安徽','芜湖','安徽','滁州','安徽','淮南','安徽','宿州','安徽','安庆','安徽','合肥','安徽','六安','宁夏回族自治区','银川','天津','天津','天津','天津','天津','天津','四川','遂宁','四川','达州','四川','绵阳','四川','泸州','四川','成都','四川','成都','四川','德阳','四川','广元','四川','巴中','四川','南充','四川','乐山','吉林','长春','吉林','长春','吉林','白城','吉林','延吉','吉林','吉林','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','北京','内蒙古','通辽','内蒙古','赤峰','内蒙古','巴彦淖尔','内蒙古','呼和浩特','内蒙古','呼和浩特','内蒙古','呼伦贝尔','内蒙古','包头','内蒙古','兴安盟','云南','西双版纳傣族自治州','云南','红河哈尼族彝族自治州','云南','玉溪','云南','楚雄州','云南','曲靖','云南','昆明','云南','昆明','云南','昆明','云南','大理白族自治州','上海','上海','上海','上海'];

