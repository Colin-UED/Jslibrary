=== Replace Google Fonts ===

Contributors: soulteary
Tags: Qihu Fonts, Qihu Web Fonts, 360 Fonts, 360 Web Fonts, Google Fonts, Google Web Fonts
Requires at least: 3.5
Tested up to: 3.8
Stable tag: 1.0

Use Qihoo 360 Open Fonts Service to replace Google's.

== Description ==

[Plugin homepage](http://www.soulteary.com/2014/06/08/) | [Plugin author](http://www.soulteary.com/) 

There are some problem with Google in china, the Google Fonts make the website too slow to open, so we can use Qihoo 360's Web Fonts replace the Google's.

[Project GitHub](https://github.com/soulteary/Replace-Google-Fonts).

== Installation ==

1. Upload `replace-google-fonts` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
